import{a as t}from"../chunks/entry.D_yyhmr8.js";export{t as start};
